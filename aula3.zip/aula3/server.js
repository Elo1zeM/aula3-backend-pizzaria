const http = require('http'); //importa o módulo nativo "http"

const colors = require('colors'); //importa o módulo colors

const fs = require('fs'); // importa o módulo nativo "fs" para ler arquivos - filesystem

const path = require('path'); //importa o módulo path para manipular "caminhos" e (rotas no express)

//simular dados dde um banco de dados
const dados = [
    {id: 1, nomedados: "Pizza de Frango c/ Catupiry", valor: 79.90},
    {id: 2, nomedados: "Pizza de Quatro Queijos", valor: 59.90},
    {id: 3, nomedados: "Pizza de Dois Amores", valor: 49.90}
];

//CRIAR O SERVIDOR

//função CALLBACK que recebe a requisição (req) e a resposta (res)
// req (Request): informações sobre pedido do usuario
// res (Response): objeto para enviar a resposta de volta ao usuario

const server = http.createServer((req, res) => {

    //log para ver qual URL está sendo acessada no terminal
    console.log(`Requisição recebida: ${req.url}` .green);

    //roteamento simples (caminho da URL)
    //ROTA HOME
    if (req.url === '/') {
        //lê o arquivo 'index.html' que geralmente está na mesma pasta do server.js, a pasta 'public'
        const filePath = path.join(__dirname, 'public', 'index.html'); //path é o caminho e o join é

        fs.readFile(filePath, (err, content) => {
            if(err) {
                res.writeHead(500);
                res.end('Erro interno do servidor');
            } else {
                res.writeHead(200, {'Content-Type': 'text/html; charset=utf-8'});
                res.end(content);
            }
        });
    }

     //rota da API retorna a tabela de dados em formato JSON
     //cria a rota: localhost:3000/api/dados --> pode ser consumida no frontend
     //ROTA API
     else if (req.url === '/api/dados'){
         res.writeHead(200, {'Content-Type': 'application/json; charset=utf-8'});
         res.end(JSON.stringify(dados));
     } 
     
     //ROTA 404
     else{
         if (req.url === '/') {
        //lê o arquivo 'index.html' que geralmente está na mesma pasta do server.js, a pasta 'public'
        const filePath = path.join(__dirname, 'public', '404.html'); //path é o caminho e o join é

        fs.readFile(filePath, (err, content) => {
            if(err) {
                res.writeHead(500);
                res.end('Página não encontrada (404)');
            }else {
               res.writeHead(404, {'Content-Type': 'text/plain; charset=utf-8'});
               res.end(content);
            }
        });
    }
     }
});

//Configurar a porta do servidor
const PORT = 3000;

//Iniciar o servidor na porta 3000
//Usar o listen para ouvir a porta
server.listen(PORT, () => {
    console.log(`Servidor rodando http>://localhost:${PORT}`.green.bold);
});





